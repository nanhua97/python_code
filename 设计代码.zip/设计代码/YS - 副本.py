#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class createNode():

    def __init__(self,row,s_id,e_id,DN,landing,s_land=0,e_land=0,s_line=0,e_line=0,s_depth=0,e_depth=0):
        self.row = row
        self.s_id = s_id
        self.e_id = e_id
        self.DN = DN
        self.landing = landing
        self.s_land = s_land
        self.e_land = e_land
        self.s_line = s_line
        self.e_line = e_line
        self.s_depth = s_depth
        self.e_depth = e_depth
def getNode(node,pNode):
    if node.DN != pNode.DN:
        node.s_line = pNode.e_line - (node.DN-pNode.DN)/1000
    else:
        node.s_line = pNode.e_line

    node.e_line = node.s_line - node.landing
    node.s_depth = node.s_land - node.s_line
    node.e_depth = node.e_land - node.e_line
    if node.s_depth > 8 or node.e_depth>8:
        print(str(node.s_id)+'-'+str(node.e_id))
    while node.s_depth > 8 or node.e_depth>8:
        node.s_depth = node.DN/1000+0.7
        node = startNode(node,node.s_depth)
        while node.e_depth < node.DN/1000+0.7:
            node.s_depth += 0.1
            node = startNode(node,node.s_depth)
    return node

def startNode(s,depth):
    s.s_depth = float(depth)
    s.s_line = s.s_land - s.s_depth
    s.e_line = s.s_line - s.landing
    s.e_depth = s.e_land - s.e_line
    while s.e_depth < s.DN/1000+0.7:
        s.s_depth += 0.1
        s = startNode(s,s.s_depth)
    
    return s
    

if __name__ == '__main__':
    f = xlrd.open_workbook('Wushui1.xls')

    copybook = copy(f)

    sheet = f.sheet_by_name('Sheet1')

    sheetChange = copybook.get_sheet(0)

    nrows = sheet.nrows

    nodeList = []

    f_depth = input('输入初始埋深:')

    for i in range(nrows):

        row = sheet.row_values(i)

        if row[0]:

            #s_id,e_id,管径，降落量，起始地面，结束地面
            row = createNode(i,row[0],row[1],row[2],row[3],float(row[4]),float(row[5]))

            nodeList.append(row)
    
    for s in nodeList:
        
        parentNode = []

        for k in nodeList:

            if s.s_id == k.e_id:
                
                parentNode.append(k)

        if len(parentNode) == 0:
            s.s_depth = float(f_depth)
            s = startNode(s,s.s_depth)
            
        elif len(parentNode) == 1:
            pNode = parentNode[0]
            s = getNode(s,pNode)
            '''
            s.delta_t = pNode.time
            s.time = (s.line_len/s.speed)/60
            s.d_flow = (1736.8/pow((s.delta_t+25),0.81))*0.5
            s.s_flow = s.area*s.d_flow
            s.landing = s.line_len*s.grade*0.001
            if s.DN != pNode.DN:
                s.s_line = pNode.e_line - (s.DN-pNode.DN)/1000
            else:
                s.s_line = pNode.e_line
            '''
        elif len(parentNode) == 2:
            pNode = parentNode[0]
            for i in parentNode:
                if i.e_line<pNode.e_line:
                    pNode = i
            s = getNode(s,pNode)
        else:
            print('多余的节点:%d' % s.s_id)
            
        sheetChange.write(s.row,7,round(s.s_line,3))
        sheetChange.write(s.row,8,round(s.e_line,3))
        sheetChange.write(s.row,9,round(s.s_depth,2))
        sheetChange.write(s.row,10,round(s.e_depth,2))

    copybook.save('Wushui1.xls')

        
        
        
                
                
            
            
            
        
