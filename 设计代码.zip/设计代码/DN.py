#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class sql_q():
    def __init__(self,q_flow,DN,grade,speed):
        self.q_flow = q_flow
        self.DN = DN
        self.grade = grade
        self.speed = speed
class createNode():
    def __init__(self,row,s_id,e_id,area,line):
        self.row = row
        self.s_id = s_id
        self.e_id = e_id
        self.line = line
        self.area = area
        self.delta_t = 0
        self.time =0
        self.d_flow = 0
        self.s_flow = 0
        self.f_s_flow = 0
        self.DN = 0
        self.grade = 0
        self.speed = 0
def getDN(n,sql):

    cha = []
    
    for i in sql:

        c = pow(n.s_flow - float(i.q_flow),2)

        cha.append(c)

    ind = cha.index(min(cha))

    s = sql[ind]

    n.f_s_flow = s.q_flow
            
    n.DN = s.DN

    n.grade = s.grade

    n.speed = s.speed

    n.time = n.line/n.speed/60

    return n

        
    
if __name__ == "__main__":
    sqlList = []
    
    sql_file = xlrd.open_workbook("DN.xls")

    sql_sheet = sql_file.sheet_by_name('Sheet1')

    sql_rows = sql_sheet.nrows

    for i in range(sql_rows):

        row = sql_sheet.row_values(i)

        record = sql_q(row[0],row[1],row[2],row[3])

        sqlList.append(record)

    sheet = sql_file.sheet_by_name('Sheet2')

    copybook = copy(sql_file)

    sheetChange = copybook.get_sheet(2)

    nrows = sheet.nrows

    nodeList = []

    for i in range(nrows):
        
        row = sheet.row_values(i)
        #s_id,e_id,管长，面积
        node = createNode(i,row[1],row[2],row[3],row[4])

        nodeList.append(node)

    for n in nodeList:
        
        parentNode = []
        
        for k in nodeList:

            if n.s_id == k.e_id:

                parentNode.append(k)
                
        if len(parentNode)==0:

            n.delta_t = 0
            #NH  =0.645*1803/(F49+15+8.64)^0.8
            #n.d_flow = 1803*0.645/pow(n.delta_t+15+8.64,0.8)

            #BL
            #n.d_flow = 1736.8*0.629/pow(n.delta_t+15+10,0.81)

            #FRZ
            #n.d_flow = 3340*0.628/pow(n.delta_t+15.8+10,0.93)

            #n.d_flow = 0.625*1532.7/pow(n.delta_t+10+6.9,0.87)

            n.d_flow = 0.63*1532.7/pow(n.delta_t+6.9,0.87)           
            n.s_flow = n.area * n.d_flow

            n = getDN(n,sqlList)

        elif len(parentNode)==1:

            pNode = parentNode[0]

            n.delta_t = pNode.delta_t + pNode.time

            #n.d_flow = 3340*0.628/pow(n.delta_t+15.8+10,0.93)

            #n.d_flow = 1803*0.645/pow(n.delta_t+15+8.64,0.8)

            #n.d_flow = 1736.8*0.629/pow(n.delta_t+15+10,0.81)
            n.d_flow = 0.63*1532.7/pow(n.delta_t+6.9,0.87)
            n.s_flow = n.area * n.d_flow

            n = getDN(n,sqlList)

        elif len(parentNode)==2:

            n.delta_t = max(parentNode[0].delta_t+parentNode[0].time,parentNode[1].delta_t+parentNode[1].time)

            n.d_flow = 0.63*1532.7/pow(n.delta_t+6.9,0.87)
            #n.d_flow = 1803*0.645/pow(n.delta_t+15+8.64,0.8)

            #n.d_flow = 3340*0.628/pow(n.delta_t+15.8+10,0.93)

            #n.d_flow = 1736.8*0.629/pow(n.delta_t+15+10,0.81)

            n.s_flow = n.area * n.d_flow

            n = getDN(n,sqlList)

        elif len(parentNode)==3:

            n.delta_t = max(parentNode[0].delta_t+parentNode[0].time,parentNode[1].delta_t+parentNode[1].time,parentNode[2].delta_t+parentNode[2].time)

            n.d_flow = 0.63*1532.7/pow(n.delta_t+6.9,0.87)
            #n.d_flow = 3340*0.628/pow(n.delta_t+15.8+10,0.93)

            #n.d_flow = 1803*0.645/pow(n.delta_t+15+8.64,0.8)

            #n.d_flow = 1736.8*0.629/pow(n.delta_t+15+10,0.81)

            n.s_flow = n.area * n.d_flow

            n = getDN(n,sqlList)

        sheetChange.write(n.row,1,str(n.s_id)+'-'+str(n.e_id))
        sheetChange.write(n.row,2,n.line)
        sheetChange.write(n.row,3,round(n.area,2))
        sheetChange.write(n.row,4,round(n.delta_t,2))
        sheetChange.write(n.row,5,round(n.time,2))
        sheetChange.write(n.row,6,round(n.d_flow,2))
        sheetChange.write(n.row,8,round(n.s_flow,2))
        sheetChange.write(n.row,9,round(n.f_s_flow,2))
        sheetChange.write(n.row,11,n.DN)
        sheetChange.write(n.row,12,round(n.grade,2))
        sheetChange.write(n.row,13,round(n.speed,2))

    copybook.save('DN.xls')
            

            

            

            

            
        

    
    

    

    
        
