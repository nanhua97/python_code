#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy
import random

if __name__ == '__main__':
    f = xlrd.open_workbook('Wushui1.xls')

    copybook = copy(f)

    sheet = f.sheet_by_name('Sheet1')

    sheetChange = copybook.get_sheet(0)

    cols = sheet.col_values(0)

    row = 0

    for i in cols:
        if isinstance(i,int):
            num = i*10 - random.random()*3
            sheetChange.write(row,2,round(num,1))
        row += 1
copybook.save('Wushui1.xls')
