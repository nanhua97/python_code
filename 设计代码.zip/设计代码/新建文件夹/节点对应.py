#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

f = xlrd.open_workbook('Wushui4.xls')

copybook = copy(f)

sheet = f.sheet_by_name('Sheet5')

#sheetWrite = f.sheet_by_name('Sheet3')
sheetWrite = f.sheet_by_name('Sheet4')

#sheetChange = copybook.get_sheet(2)
sheetChange = copybook.get_sheet(3)

nodeList = []

#nodeNum = sheet.col_values(0)
#nodeHeight = sheet.col_values(1)

nodeNum = sheet.col_values(2)
nodeHeight = sheet.col_values(3)

for i in range(len(nodeNum)):
    if nodeNum[i]!='':
        nodeDic = {'id':nodeNum[i],'height':nodeHeight[i]}
        nodeList.append(nodeDic)


nrow = sheetWrite.nrows

for i in range(nrow):
    row = sheetWrite.row_values(i)
    if row[1]!='':
        for j in nodeList:
            
            if int(j['id']) == int(row[1]):
                sheetChange.write(i,7,j['height'])

            if int(j['id']) == int(row[2]):
                sheetChange.write(i,8,j['height'])
    

copybook.save('Wushui4.xls')

