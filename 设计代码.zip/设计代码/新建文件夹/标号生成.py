#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy
import random

'''
s = input("请输入(以空格符分割)：")

k = s.split(' ')

f = open('wushui1.xls','w+')
for i in k:
    if '-' in i:
        f.write(i)
        f.write('\n')
    elif '~' in i:
        start,end = i.split('~')
        start = int(start)
        end = int(end)
        while start<end:
            f.write(str(start)+'-'+str(start+1))
            f.write('\n')
            start += 1

f.close()
def node(o,k):
	while old<s:
            print(str(o)+'-'+str(o+1))
            if o+1 == k:
                print(str(k))


old = 0
f = open('wushui.xls','w+')
while True:
    s = int(input("请输入汇入节点:"))
    if s==0:
        old=0
    elif s==-1:
        break
    if old != 0:
        f.write(str(old)+'-'+str(s))
        f.write('\t')
        f.write(str(s))
        f.write('\n')
        old += 1
        while old<s:
            f.write(str(old)+'-'+str(old+1))
            if old+1 == s:
                f.write('\t')
                f.write(str(s))
            f.write('\n')
            old += 1
            
    old = s
f.close()
'''
f = xlrd.open_workbook('Wushui1.xls','w+')
copybook = copy(f)
sheetChange = copybook.get_sheet(0)
row = 0
while True:
    s = int(input("请输入汇入节点:"))
    if s==0:
        old=0
        sheetChange.write(row,0,' ')
        row += 1
    elif s==-1:
        break
    if old != 0:
        if old > s:
            sheetChange.write(row,0,str(old)+'-'+str(s))
            row += 1
        while old<s:
            sheetChange.write(row,0,str(old)+'-'+str(old+1))
            old += 1
            row += 1
            
    old = s
    
copybook.save('Wushui1.xls')
