#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class createNode():
    def __init__(self,row,flow):
        self.row = row
        self.flow = flow

if __name__ == '__main__':
    f = xlrd.open_workbook('Wushui1.xls')
    copybook = copy(f)
    sheet = f.sheet_by_name('Sheet1')
    sheetChange = copybook.get_sheet(0)
    nrows = sheet.nrows
    nodeList = []
    for i in range(nrows):

        row = sheet.row_values(i)

        if row[0]:

            row = createNode(i,row[0])

            nodeList.append(row)

    for k in nodeList:

        if k.flow<=10000:
            k.cost = 12460
        elif 10000<k.flow<=20000:
            k.cost = 12460 - (k.flow-10000)*0.3109
        elif 20000<k.flow<=50000:
            k.cost = 9351 - (k.flow-20000)*0.121567
        elif 50000<k.flow<=100000:
            k.cost = 5704 - (k.flow-50000)*0.02412
        else:
            k.cost = 4498
        sheetChange.write(k.row,1,k.cost*0.8052)
        sheetChange.write(k.row,2,k.cost*0.1208)
        sheetChange.write(k.row,3,k.cost*0.0741)
        sheetChange.write(k.row,4,k.cost)
    copybook.save('Wushui1.xls')














            
        
