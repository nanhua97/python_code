#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class createNode():
    #已知的：行号 起始编号[1] 结束编号[2] 管长[3] 汇水面积[4] 管径[7] 坡度[8] 流速[9] 地面起点标高[11] 地面终点标高[12]
    #要求：管内雨水流行面积delta_t t 单位面积径流量 设计流量 坡降 设计管内底标高起点 终点 埋深起点 终点
    def __init__(self,row,s_id,e_id,line_len,area,DN=0,grade=0,speed=0,s_land=0,e_land=0,delta_t=0,time=0,d_flow=0,s_flow=0,landing=0,s_line=0,e_line=0,s_depth=0,e_depth=0):
        self.row = row
        self.s_id = s_id
        self.e_id = e_id
        self.line_len = line_len
        self.area = area
        self.DN = DN
        self.grade = grade
        self.speed = speed
        self.s_land = s_land
        self.e_land = e_land
        self.delta_t = delta_t
        self.time = time
        self.d_flow = d_flow
        self.s_flow = s_flow
        self.landing = landing
        self.s_line = s_line
        self.e_line = e_line
        self.s_depth = s_depth
        self.e_depth = e_depth
def getNode(node,pNode):
    node.delta_t = pNode.time + pNode.delta_t
    node.time = (node.line_len/node.speed)/60
    node.d_flow = (1803/pow((node.delta_t+15+8.64),0.8))*0.5
    node.s_flow = node.area*node.d_flow
    '''
    node.landing = node.line_len*node.grade*0.001
    if node.DN != pNode.DN:
        node.s_line = pNode.e_line - (node.DN-pNode.DN)/1000
    else:
        node.s_line = pNode.e_line

    node.e_line = node.s_line - node.landing
    node.s_depth = node.s_land - node.s_line
    node.e_depth = node.e_land - node.e_line
    '''
    return node

if __name__ == '__main__':
    f = xlrd.open_workbook('Wushui1.xls')

    copybook = copy(f)

    sheet = f.sheet_by_name('Sheet1')

    sheetChange = copybook.get_sheet(1)

    nrows = sheet.nrows

    nodeList = []

    for i in range(nrows):

        row = sheet.row_values(i)

        if not isinstance(row[1],str):

            #已知的：行号 起始编号[1] 结束编号[2] 管长[3] 汇水面积[4] 管径[7] 坡度[8] 流速[9] 地面起点标高[11] 地面终点标高[12]
            #要求：管内雨水流行面积delta_t time 单位面积径流量 设计流量 坡降 设计管内底标高起点 终点 埋深起点 终点

            row = createNode(i,row[0],row[1],row[2],row[3])

            nodeList.append(row)

    for s in nodeList:
        
        parentNode = []

        for k in nodeList:

            if s.s_id == k.e_id:
                
                parentNode.append(k)

        if len(parentNode) == 0:

            s.delta_t = 0
            #s.s_depth = 1.8
            if s.line_len>0:
                s.time = (s.line_len/s.speed)/60
            s.d_flow = (1736.8/pow((s.delta_t+25),0.81))*0.5
            s.s_flow = s.area*s.d_flow
            '''
            s.landing = s.line_len*s.grade*0.001
            s.s_line = s.s_land - s.s_depth
            s.e_line = s.s_line - s.landing
            s.e_depth = s.e_land - s.e_line
            '''
        elif len(parentNode) == 1:
            pNode = parentNode[0]
            s = getNode(s,pNode)
            '''
            s.delta_t = pNode.time
            s.time = (s.line_len/s.speed)/60
            s.d_flow = (1736.8/pow((s.delta_t+25),0.81))*0.5
            s.s_flow = s.area*s.d_flow
            s.landing = s.line_len*s.grade*0.001
            if s.DN != pNode.DN:
                s.s_line = pNode.e_line - (s.DN-pNode.DN)/1000
            else:
                s.s_line = pNode.e_line
            '''
        elif len(parentNode) == 2:
            if parentNode[0].e_line <parentNode[1].e_line:
                pNode = parentNode[0]
            else:
                pNode = parentNode[1]

            s = getNode(s,pNode)
        else:
            print('多余的节点:%d' % s.s_id)
            
        sheetChange.write(s.row,1,str(int(s.s_id))+'-'+str(int(s.e_id)))
        sheetChange.write(s.row,2,s.line_len)
        sheetChange.write(s.row,3,round(s.area,2))
        sheetChange.write(s.row,4,round(s.delta_t,2))
        sheetChange.write(s.row,5,round(s.time,2))
        sheetChange.write(s.row,6,round(s.d_flow,2))
        sheetChange.write(s.row,7,round(s.s_flow,2))
        sheetChange.write(s.row,8,s.DN)
        sheetChange.write(s.row,9,round(s.grade,2))
        sheetChange.write(s.row,10,round(s.speed,2))
        sheetChange.write(s.row,11,round(s.landing,3))
        sheetChange.write(s.row,12,round(s.s_land,2))
        sheetChange.write(s.row,13,round(s.e_land,2))
        sheetChange.write(s.row,14,round(s.s_line,3))
        sheetChange.write(s.row,15,round(s.e_line,3))
        sheetChange.write(s.row,16,round(s.s_depth,2))
        sheetChange.write(s.row,17,round(s.e_depth,2))

    copybook.save('Wushui1.xls')

        
        
        
                
                
            
            
            
        
