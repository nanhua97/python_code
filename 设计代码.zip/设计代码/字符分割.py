#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

f = xlrd.open_workbook('Wushui1.xls')

sheet = f.sheet_by_name('Sheet1')

copybook = copy(f)

sheetChange = copybook.get_sheet(0)

fu = input('请输入分隔符:')

col1 = sheet.col_values(0)
row = 0
for i in col1:
    if fu in i:
        i = i.strip()
        nums = i.split(fu)
        
        if nums[0].isdigit():
            sheetChange.write(row,1,int(nums[0]))
        else:
            sheetChange.write(row,1,nums[0])
            
        if nums[1].isdigit():
            sheetChange.write(row,2,int(nums[1]))
        else:
            sheetChange.write(row,2,nums[1])
    #sheetChange.write(row,3,str(int(nums[0])-2)+'-'+str(int(nums[1])-2))

    row += 1

copybook.save('Wushui1.xls')
