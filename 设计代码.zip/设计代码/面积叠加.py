#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class createNode():
    def __init__(self,row,s_id,e_id,b_area=0,z_area=0):
        self.row = row
        self.start = s_id
        self.end = e_id
        if isinstance(b_area,str):
            self.b_area = 0
        else:
            self.b_area = round(b_area,2)
        self.z_area = z_area


if __name__ == '__main__':
    nodeList = []

    f = xlrd.open_workbook('Wushui1.xls')

    copybook = copy(f)

    sheet = f.sheet_by_name('Sheet1')

    sheetChange = copybook.get_sheet(0)

    nrow = sheet.nrows

    for i in range(nrow):
        row = sheet.row_values(i)
        if row[0]:
            #s_id,e_id,本段面积
            node = createNode(i,row[0],row[1],row[2],0)
            nodeList.append(node)
    for j in nodeList:
        for k in nodeList:
            if k.start == j.end:
                k.z_area += j.b_area+j.z_area


    for s in nodeList:
        sheetChange.write(s.row,3,s.z_area)
    copybook.save('Wushui1.xls')
    
