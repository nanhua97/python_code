#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class sql_q():
    def __init__(self,q_flow,DN,grade,speed,fill):
        self.q_flow = q_flow
        self.DN = DN
        self.grade = grade
        self.speed = speed
        self.fill = fill
class createNode():
    def __init__(self,row,s_flow):
        self.row = row
        self.s_flow = s_flow
        self.DN = 0
        self.grade = 0
        self.speed = 0
        self.fill = 0

def getDN(n,sql):

    cha = []
    
    for i in sql:

        c = pow(n.s_flow - float(i.q_flow),2)

        cha.append(c)

    ind = cha.index(min(cha))

    s = sql[ind]

    n.f_s_flow = s.q_flow

    n.DN = s.DN

    n.grade = s.grade

    n.speed = s.speed

    n.fill = s.fill

    return n
if __name__ == "__main__":
    sqlList = []
    
    sql_file = xlrd.open_workbook("W_DN.xls")

    sql_sheet = sql_file.sheet_by_name('Sheet1')

    sql_rows = sql_sheet.nrows

    for i in range(sql_rows):

        row = sql_sheet.row_values(i)

        record = sql_q(row[0],row[1],row[2],row[3],row[4])

        sqlList.append(record)

    sheet = sql_file.sheet_by_name('Sheet2')

    copybook = copy(sql_file)

    sheetChange = copybook.get_sheet(1)

    nrows = sheet.nrows

    nodeList = []

    for i in range(nrows):
        
        row = sheet.row_values(i)

        node = createNode(i,row[1])

        nodeList.append(node)

    for n in nodeList:
        
        n = getDN(n,sqlList)

        sheetChange.write(n.row,2,n.f_s_flow)
        sheetChange.write(n.row,3,n.DN)
        sheetChange.write(n.row,4,n.grade)
        sheetChange.write(n.row,5,n.speed)
        sheetChange.write(n.row,6,n.fill)

    copybook.save('W_DN.xls')
        
            

    

    

    
