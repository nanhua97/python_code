#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class createNode():
    def __init__(self,row,area):
        self.row = row
        self.area = area

if __name__ == '__main__':
    f = xlrd.open_workbook('Wushui1.xls')
    copybook = copy(f)
    sheet = f.sheet_by_name('Sheet1')
    sheetChange = copybook.get_sheet(0)
    nrows = sheet.nrows
    nodeList = []
    for i in range(nrows):

        row = sheet.row_values(i)

        if row[0]:

            row = createNode(i,row[0])

            nodeList.append(row)
    for k in nodeList:

        if k.area <= 50:
            k.j_cost = 21856
            k.o_cost = 3278
            k.b_cost = 2011
        elif 50<k.area<=100:
            k.j_cost = 21856 - (k.area -50) * 39.42
            k.o_cost = 3278 - (k.area - 50) * 5.9
            k.b_cost = 2011 - (k.area - 50) * 3.64
        elif 100<k.area<=200:
            k.j_cost = 19885 - (k.area -100) * 77.34
            k.o_cost = 2983 - (k.area - 100) * 11.6
            k.b_cost = 1829 - (k.area - 100) * 7.11
        else:
            k.j_cost = 12151
            k.o_cost = 1823
            k.b_cost = 1118
        k.cost = k.j_cost+k.o_cost+k.b_cost
        sheetChange.write(k.row,1,k.j_cost)
        sheetChange.write(k.row,2,k.o_cost)
        sheetChange.write(k.row,3,k.b_cost)
        sheetChange.write(k.row,4,k.cost)
    copybook.save('Wushui1.xls')
        












            
