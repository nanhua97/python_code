#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

'''
fileRead = input('输入来源文件名:')

sheetReadName = input('输入来源表格名:')

sheetReadCol = input('输入数据来源列:')

fileWrite = input('输入写入文件名:')

sheetWriteName = input('输入写入表格名:')

sheetWriteNum = input('输入写入表格序号(文件中第几张表):')

sheetWriteCol = input('输入新文件中数据列:')

fileRead = xlrd.open_workbook(fileRead)

fileWrite  = xlrd.open_workbook(fileWrite)

sheetRead = fileRead.sheet_by_name(fileOld)

sheetWrite = fileRead.sheet_by_name(fileNew)

copybook = copy(sheetWrite)

sheetChange = copybook.get_sheet(int(sheetWriteNum))

MesList = []

nrows = sheetRead.nrows

read_col = int(sheetReadCol) - 1

for i in range(nrows):
    
    row = sheetRead.row_values(i)
    
    if isinstance(row[read_col],int):
        
        dic = {'id':row[read_col],'mes':row[read_col+1]}

        MesList.append(dic)

write_col = int(sheetWriteCol) - 1

nrows = sheetWrite.nrows

for i in range(nrows):
    
    row = sheetWrite.row_values(i)
    
    if isinstance(row[write_col],int):
        
        for mes in MesList:
            
            if int(mes['id']) == int(row[write_col]):
                
                sheetChange.write(i,write_col,mes['mes'])

copybook.save(fileWrite)
    

    
    
'''

f = xlrd.open_workbook('Wushui1.xls')

copybook = copy(f)
#获取表格名
#sheet1_name = f.sheet_names()[0]

sheet = f.sheet_by_name('Sheet1')
sheetChange = copybook.get_sheet(0)

valList = []

nrows = sheet.nrows
for i in range(nrows):
    
    row = sheet.row_values(i)
    if row[0]:

        dic = {'key':row[0],'value':row[1]}

        valList.append(dic)
        


nrows = sheet.nrows

for i in range(nrows):

    row = sheet.row_values(i)
    '''
    if row[2]:
        for j in AreaList:
            if int(j['id'])==int(row[2]):
                print(str(row[2])+'\t'+str(j['area']))
    '''
    if row[2]:
        for j in valList:
            if j['key']==row[2]:
                sheetChange.write(i,3,j['value'])

copybook.save('Wushui1.xls')


