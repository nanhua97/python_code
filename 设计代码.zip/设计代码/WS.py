#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class createNode():
    #第几行 管段起始标号 管段结束标号 管径 充满度 降落量 地面上端 下端 水面上端 下端 管内底上端 下端 埋设深度上端 下端
    def __init__(self,row,start_id,end_id,DN,fill,landing,start_land,end_land,start_water=0,end_water=0,start_line=0,end_line=0,start_depth=0,end_depth=0):
        self.row = row
        self.start_id = start_id
        self.DN = DN
        self.end_id =end_id
        self.fill = fill
        self.landing = landing
        self.start_land = start_land
        self.end_land = end_land
        self.start_water = start_water
        self.end_water = end_water
        self.start_line = start_line
        self.end_line = end_line
        self.start_depth = start_depth
        self.end_depth = end_depth

def getNode(j,pNode,depth):
    if j.DN ==pNode.DN:
        j.start_water = pNode.end_water #水面上端
        j.start_line = j.start_water - j.fill   #管内底上端
        j.end_line = j.start_line - j.landing   #管内底下端
    #管径不同
    elif j.DN != pNode.DN:
        j.start_line = pNode.end_line - (j.DN - pNode.DN)/1000  #管内底上端
        j.end_line = j.start_line - j.landing   #管内底下端
        j.start_water = j.start_line + j.fill   #水面上端
    j.end_water = j.end_line + j.fill   #水面下端
    j.start_depth = j.start_land - j.start_line #埋深上端
    j.end_depth = j.end_land - j.end_line   #埋深下端
    if j.start_depth > 8 or j.end_depth>8:
        print(str(j.start_id)+'-'+str(j.end_id))
        j = startNode(j,depth)
    return j
def startNode(s,depth):
    s.start_depth = depth #埋深上端
    s.start_line = s.start_land - s.start_depth #管内底上端
    s.end_line = s.start_line - s.landing   #管内底下端
    s.start_water = s.start_line + s.fill   #水面上端
    s.end_water = s.end_line + s.fill   #水面下端
    s.end_depth = s.end_land - s.end_line   #埋深下端
    return s


if __name__ == '__main__':

    f = xlrd.open_workbook('Wushui1.xls')

    copybook = copy(f)

    sheet = f.sheet_by_name('Sheet1')

    sheetChange = copybook.get_sheet(0)
    
    nrows = sheet.nrows

#    base = int(input('请输入降落量ID:'))

    nodeList = []

    start_depth = float(input('请输入初始埋深:'))

    for i in range(nrows):

        row = sheet.row_values(i)
        
        if not isinstance(row[0],str):
            #第几行 管段起始标号 管段结束标号 管径 充满度 降落量 地面上端 下端 水面上端 下端 管内底上端 下端 埋设深度上端 下端
            row = createNode(i,row[0],row[1],row[2],row[3],row[4],row[5],row[6])


            #row = createNode(i,row[1],row[2],)
            
            nodeList.append(row)

    for s in nodeList:

        parentNode = []

        for k in nodeList:
            
            if s.start_id == k.end_id:

                parentNode.append(k)
        
        
        #初始节点
        if len(parentNode)==0:

            #print('%d是一个初始节点' % j.start_id)
            s = startNode(s,start_depth)
        
        else:
            pNode = parentNode[0]
            for i in parentNode:
                if i.end_line<pNode.end_line:
                    pNode = i
            s = getNode(s,pNode,start_depth)

            
                
        #start_water=0,end_water=0,start_line=0,end_line=0,start_depth=0,end_depth=0
        sheetChange.write(s.row,8,s.start_water)
        sheetChange.write(s.row,9,s.end_water)
        sheetChange.write(s.row,10,s.start_line)
        sheetChange.write(s.row,11,s.end_line)
        sheetChange.write(s.row,12,s.start_depth)
        sheetChange.write(s.row,13,s.end_depth)
    copybook.save('Wushui1.xls')
        

    
'''
        #承接上一个节点
        elif len(parentNode)==1:

            #print('%d 的上一个节点是 %d' % (j.start_id,parentNode[0].start_id))
            pNode = parentNode[0]
            if s.DN ==pNode.DN:
                s.start_water = pNode.end_water #水面上端
                s.start_line = s.start_water - s.fill   #管内底上端
                s.end_line = s.start_line - s.landing   #管内底下端
                s.end_water = s.end_line + s.fill   #水面下端
                s.start_depth = s.start_land - s.start_line #埋深上端
                s.end_depth = s.end_land - s.end_line   #埋深下端
            #管径不同
            else:
                s.start_line = pNode.end_line - (s.DN - pNode.DN)/1000  #管内底上端
                s.end_line = s.start_line - s.landing   #管内底下端
                s.start_water = s.start_line + s.fill   #水面上端
                s.end_water = s.end_line + s.fill   #水面下端
                s.start_depth = s.start_land - s.start_line #埋深上端
                s.end_depth = s.end_land - s.end_line   #埋深下端
            
            s = getNode(s,pNode)
        
        #汇集节点
        elif len(parentNode)==2:

            #print('%d 的上一个节点是 %d,%d' % (j.start_id,parentNode[0].start_id,parentNode[1].start_id))
            if parentNode[0].end_line > parentNode[1].end_line:
                pNode = parentNode[1]
            elif parentNode[0].end_line <= parentNode[1].end_line:
                pNode = parentNode[0]
            s = getNode(s,pNode)
        else:

            print('多余的节点:%d' % len(parentNode))
        '''
                

                
                
        
        

    
    
    

    
        
