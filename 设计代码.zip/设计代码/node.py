#coding:utf8
import xlrd
import xlwt
from xlutils.copy import copy

class createNode():
    def __init__(self,row,start,end,b_flow=0,z_flow=0):
        self.row = row
        self.start = start
        self.end = end
        if isinstance(b_flow,str):
            self.b_flow = 0
        else:
            self.b_flow = round(b_flow,2)
        self.z_flow = z_flow
    def get_a_flow(self):
        '''
        print(self.b_flow,end='\t')
        print(type(self.b_flow),end='\t')
        print(self.z_flow,end='\t')
        print(type(self.z_flow))
        '''
        return self.b_flow+self.z_flow
    def get_kz(self):
        val = self.get_a_flow()
        if val<=5:
            kz_v=2.3
        elif 5<val<15:
            kz_v = 2+0.3*(15-val)/10
        elif 15<=val<40:
            kz_v = 1.8 + 0.2*(40-val)/25
        elif 40<=val<70:
            kz_v = 1.7+0.1*(70-val)/30
        elif 70<=val<100:
            kz_v = 1.6+0.1*(100-val)/30
        elif 100<=val<200:
            kz_v = 1.5+0.1*(200-val)/100
        elif 200<=val<500:
            kz_v = 1.4+0.1*(500-val)/300
        elif 500<=val<1000:
            kz_v = 1.3+0.1*(1000-val)/500
        else:
            kz_v=1.3
        return round(kz_v,1)
    def get_flow(self):
        flow = self.get_a_flow()
        kz = self.get_kz()
        re_flow = flow*kz
        return re_flow
if __name__ == '__main__':
    nodeList = []
    f = xlrd.open_workbook('Wushui1.xls')

    copybook = copy(f)

    sheet = f.sheet_by_name('Sheet1')

    sheetChange = copybook.get_sheet(0)

    nrow = sheet.nrows


    for i in range(nrow):

        row = sheet.row_values(i)

        if isinstance(row[2],str):
            flow = 0
        else:
            flow = round(row[2],2)
        
        node = createNode(i,row[0],row[1],row[2],0)

        nodeList.append(node)
        

    for j in nodeList:
        for k in nodeList:
            if k.start == j.end:
                k.z_flow += j.get_a_flow()
                
    for s in nodeList:
        if s.z_flow !=0:
            sheetChange.write(s.row,4,round(s.z_flow,2))
        sheetChange.write(s.row,5,round(s.get_a_flow(),2))
        sheetChange.write(s.row,6,s.get_kz())
        sheetChange.write(s.row,7,s.get_flow())

copybook.save('Wushui1.xls')
